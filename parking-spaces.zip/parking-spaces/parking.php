<?php
require_once('config.php');
$conf = new Config;
$conf->header('test');   ?>


<div class="frame">
    <div id="p116" class="item green" >
        <span class="position">116</span>
        <span class="plate">ION4400</span>
    </div>
    <div id="p117" class="item red">
        <span class="position">117</span>
        <span class="plate">IMM1492</span>
    </div>
    <div id="p118" class="item green">
        <span class="position">118</span>
        <span class="plate">XNN8998</span>
    </div>
    <div id="p120" class="item green">
        <span class="position">120</span>
        <span class="plate">IYM8315</span>
    </div>
    <div id="p121" class="item red">
        <span class="position">121</span>
        <span class="plate">IZO1743</span>
    </div>
    <div id="p122" class="item red">
        <span class="position">122</span>
        <span class="plate">IOH9300</span>
    </div>
    <div id="p115" class="item green">
        <span class="position">115</span>
        <span class="plate">XNN1699</span>
    </div>
    <div id="p110" class="item red">
        <span class="position">110</span>
        <span class="plate">XNI1026</span>
    </div>
    <div id="p109" class="item red">
        <span class="position">109</span>
        <span class="plate">XNX9369</span>
    </div>
    <div id="p108" class="item green">
        <span class="position">108</span>
        <span class="plate">YNY4428</span>
    </div>
    <div id="p107" class="item green">
        <span class="position">107</span>
        <span class="plate">XNT5226</span>
    </div>
    <div id="p106" class="item red">
        <span class="position">106</span>
        <span class="plate">HKT2392</span>
    </div>
    <div id="p105" class="item red">
        <span class="position">105</span>
        <span class="plate">IMK6725</span>
    </div>
    <div id="p114" class="item red">
        <span class="position">114</span>
        <span class="plate">IHK4726</span>
    </div>
    <div id="p113" class="item green">
        <span class="position">113</span>
        <span class="plate">XNN7733</span>
    </div>
    <div id="p112" class="item red">
        <span class="position">112</span>
        <span class="plate">XNT6457</span>
    </div>
    <div id="p111" class="item green">
        <span class="position">111</span>
        <span class="plate">PEH8295</span>
    </div>
    <div id="p134" class="item red">
        <span class="position">134</span>
        <span class="plate">TYT431</span>
    </div>
    <div id="p133" class="item red">
        <span class="position">133</span>
        <span class="plate">XNI9464</span>
    </div>
    <div id="p132" class="item green">
        <span class="position">132</span>
        <span class="plate">XNP9546</span>
    </div>
    <div id="p131" class="item green">
        <span class="position">131</span>
        <span class="plate">PMN485</span>
    </div>
    <div id="p123" class="item red">
        <span class="position">123</span>
        <span class="plate">HKZ7622</span>
    </div>
    <div id="p124" class="item red">
        <span class="position">124</span>
        <span class="plate">XNX2324</span>
    </div>
    <div id="p125" class="item green">
        <span class="position">125</span>
        <span class="plate">XNI4058</span>
    </div>
    <div id="p126" class="item red">
        <span class="position">126</span>
        <span class="plate">ZXH8522</span>
    </div>
    <div id="p127" class="item green">
        <span class="position">127</span>
        <span class="plate">IPA5341</span>
    </div>
    <div id="p128" class="item red">
        <span class="position">128</span>
        <span class="plate">MYZ7892</span>
    </div>
    <div id="p129" class="item red">
        <span class="position">129</span>
        <span class="plate">XNK4092</span>
    </div>
    <div id="p130" class="item green">
        <span class="position">130</span>
        <span class="plate">XNI9996</span>
    </div>
    <div id="p102" class="item green">
        <span class="position">102</span>
        <span class="plate">XNP8218</span>
    </div>
    <div id="p101" class="item red">
        <span class="position">101</span>
        <span class="plate">XN03305</span>
    </div>
</div>

<?php
$conf->footer();